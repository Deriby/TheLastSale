"""Build the portable Godot project ZIP; keep engine caches and exports outside it."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent.parent
VERSION = "0.40.0"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=ROOT / "downloads/project" / f"TheLastSale_Godot_{VERSION}.zip")
    args = parser.parse_args()
    sources = {}
    for folder in ["assets", "scenes", "scripts", "resources", "shaders", "tools", "tests"]:
        for path in sorted((ROOT / folder).rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(ROOT)
            if relative.is_relative_to("assets/models/originals"):
                continue
            if "__pycache__" in relative.parts or path.name.endswith(".blend1"):
                continue
            sources[relative.as_posix()] = path
    for name in ["project.godot", "export_presets.cfg", ".gitignore",
                 "docs/.gdignore", "docs/user_models_report.json", "docs/PENDENCIAS.md", "docs/surface_report.json",
                 "docs/CAMPANHA_TRES_NOITES.md", "docs/ELENCO_PROVISORIO.md"]:
        sources[name] = ROOT / name
    for gallery in ["optimization_v011", "friday_v018", "saturday_v019", "sunday_v020", "supplies_v021", "natural_v022", "npc_cast_draft"]:
        for path in sorted((ROOT / "docs" / gallery).rglob("*")):
            if path.is_file() and path.name != "motion_comparison.mp4" and not (gallery == "friday_v018" and path.suffix.lower() == ".png"):
                sources[path.relative_to(ROOT).as_posix()] = path
    # The Friday 0.18 screenshots remain in the GitHub gallery; reserve room
    # in the project ZIP for the full uploaded title song.
    # Keep the editor ZIP below GitHub's 100 MiB per-file limit. Full comparison
    # galleries remain published in the repository; include the PSX guide and two views.
    for name in ["README.md", "validation.json", "ps1_soft.png", "settings.png"]:
        relative = "docs/psx_v023/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json", "fixed_ps12.png"]:
        relative = "docs/psx_v0231/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/title_v024/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/title_v0241/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/title_v0242/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json", "kinematic_metrics.json", "sole_contact.json"]:
        relative = "docs/motion_v025/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json", "kinematic_metrics.json", "sole_contact.json"]:
        relative = "docs/motion_v026/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json", "gait_metrics.json", "before_after.json"]:
        relative = "docs/sprint_v027/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/everyday_v028/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/friday_story_v029/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/scares_v030/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/killer_v0301/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/subtle_v0302/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/watching_v031/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/unease_v032/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/climax_v033/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/desktop_v034/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/guidance_v035/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/review_v036/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/music_v037/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/horror_v038/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/panels_v039/" + name
        sources[relative] = ROOT / relative
    for name in ["README.md", "validation.json"]:
        relative = "docs/visual_v040/" + name
        sources[relative] = ROOT / relative
    sources["README.md"] = ROOT / "tools/project_archive_readme.md"
    records = {name: {"bytes": path.stat().st_size,
                       "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
               for name, path in sorted(sources.items())}
    manifest = {"project": "Deriby/TheLastSale", "version": VERSION,
                "godot": "4.7", "entry": "project.godot", "files": records}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(sources.items()):
            info = zipfile.ZipInfo("TheLastSale/" + name, date_time=(2026, 10, 30, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100755 if name.endswith(".sh") else 0o100644) << 16
            archive.writestr(info, path.read_bytes(), compresslevel=9)
        archive.writestr("TheLastSale/PROJETO_MANIFESTO.json",
                         json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    with zipfile.ZipFile(args.output) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError("CRC failure: " + bad)
        for name, record in records.items():
            actual = hashlib.sha256(archive.read("TheLastSale/" + name)).hexdigest()
            if actual != record["sha256"]:
                raise RuntimeError("Packaged file mismatch: " + name)
    digest = hashlib.sha256(args.output.read_bytes()).hexdigest()
    args.output.with_suffix(".sha256").write_text(digest + "  " + args.output.name + "\n")
    print(json.dumps({"path": str(args.output), "bytes": args.output.stat().st_size,
                      "files": len(records), "sha256": digest}, indent=2))


if __name__ == "__main__":
    main()
