# The Last Sale — projeto Godot 0.26.0

1. Extraia este ZIP em uma pasta nova.
2. No Godot **4.4.1**, clique em **Importar** e escolha `project.godot`.
3. Aguarde a importação dos modelos e texturas.
4. Pressione **F5** e escolha **Iniciar expediente** para testar a rotina completa.

Modelos animados, cenários, sons, texturas, código, testes e ferramentas estão incluídos. Blender não é necessário para jogar. O renderizador é Compatibility / OpenGL.

## Animações refeitas — 0.26.0

A base de caminhada, corrida, repouso, agachamento e conversa usa animações de Quaternius (CC0), adaptadas aos 11 rigs sem modificar suas malhas, texturas ou pesos. O apoio dos pés segue o contato de cada referência, e os clientes modulares receberam o pivô correto da manga. Protagonistas, garotas, homens, Zirico e Bryan têm variações próprias. As ações de caixas conservam seus tempos e controles. Veja `docs/motion_v026/README.md` e a licença em `tools/motion_reference/`.

As bibliotecas prontas são usadas pelo jogo. Não é necessário baixar referências, instalar scipy ou executar Blender. Para regenerar, execute `tools/bake_natural_motion.tscn` no Godot 4.4.1.

## Movimento dos personagens — 0.25.0

Há perfis próprios para Deryk e Felps, garotas, homens, senhora, Zirico bêbado e Bryan inquieto. Os 11 rigs têm bibliotecas de movimento medidas; as malhas, texturas e os pesos dos modelos não foram alterados. Os clientes homens e o cliente do aviso também usam esse controlador.

A passada acompanha a distância realmente percorrida, para quando o corpo está bloqueado e volta quando o caminho abre. Gestos de repouso são finitos; Bryan tem gestos mais frequentes, enquanto Zirico usa base mais larga e braços de equilíbrio. As transições limpam apoios antigos e suavizam a estabilização horizontal dos pés. Ações de pegar, colocar, largar caixas e atacar conservam os clipes e tempos originais.

Perfis ficam em `resources/locomotion_profiles.json`; as bibliotecas prontas estão em `resources/motion/`. Não é necessário Blender nem regenerar animações para jogar. Para refazer as bibliotecas, execute a cena `tools/bake_natural_motion.tscn` no Godot 4.4.1. Veja `docs/motion_v025/README.md`. Prévias em vídeo ficam no GitHub para manter o ZIP abaixo de 100 MiB.

## Intro retrô e menu de suspense — 0.24.2

Ao abrir o jogo, uma sequência de fita apresenta o estúdio **Two Brothers Lab** e o depósito em Franca às 21:40. Espaço, Enter, Esc ou clique pulam a intro e mostram o menu. O depósito vazio, a tipografia de terror dos anos 80 e a atmosfera sonora criam o fundo do menu. Configurações e continuar o checkpoint ficam disponíveis antes de iniciar a partida. A pausa não repete a intro.

O título usa Bebas Neue em duas linhas, com creme e vermelho queimado; as opções usam Special Elite e o visor usa VT323. O menu entra em etapas, a seleção responde suavemente e a câmera se aproxima devagar. O título menor e o espaço entre as opções deixam a fachada respirar. O letreiro apresenta falhas discretas e a luz ao fundo aparece ocasionalmente, com restauração completa antes da partida. Há sons distantes de carro, cachorro, metal e zumbido elétrico; todos respeitam Efeitos. Continuar informa a noite e o horário do checkpoint sem carregar a campanha. Ao iniciar, o menu se apaga com um estalo de fita e o controle só é entregue quando a transição cobre a troca de câmera. As três fontes estão incluídas com suas licenças em `assets/fonts/title/retro/`.

Fontes, sons originais e código estão prontos no pacote: não é necessário instalar ferramentas extras para jogar. As opções de volume controlam a apresentação. Modelos, animações, física, energia, HUD e a correção do piso da 0.23.1 foram preservados. Veja `docs/title_v0242/README.md`.

## Piso estável ao mover a câmera — 0.23.1

Corrige o deslizamento das texturas do piso em PS1 e PS1/2. Materiais com projeção triplanar mantêm o mapeamento preso ao cenário/objeto. A interpolação afim das texturas UV recebeu limites suaves e trata corretamente vértices atrás da câmera. As escolhas Desligada/Suave/Marcada, a precisão de vértices e a resolução continuam disponíveis. Veja `docs/psx_v0231/README.md`.

## Efeitos PS1 / PS1/2 — 0.23.0

Em Configurações, selecione PS1 (320×240) ou PS1/2 (640×480). Precisão de vértices PS1 e Texturas afins PS1 podem ser Desligada, Suave ou Marcada, independentemente. Suave é o padrão. As escolhas ficam salvas e só afetam esses dois modos. HUD e menus permanecem em resolução plena. Os modelos, animações, colisões, saves e circuitos de energia foram preservados. Veja `docs/psx_v023/README.md`.

## Movimento e acabamento do cenário — 0.22.0

A 0.22.0 inclui bibliotecas de animação medidas para cada rig: caminhada, corrida, transporte, agachamento, repouso e gestos comuns. Os pés levantam menos, a cadência acompanha o deslocamento e o tronco reage à aceleração e às curvas. Os modelos e as texturas recebidos foram preservados. Ferramentas, papéis, tapete e relógio detalham o depósito; lixeira, sarjeta e marcas de uso complementam a rua. Veja `docs/natural_v022/README.md` e o vídeo comparativo incluído.

## Reposição e pedidos: como identificar as caixas

- **R1/R2, verdes:** pegue no estoque e leve à geladeira **G1** da parede esquerda. E abre; E novamente repõe. A placa mostra quantas caixas faltam.
- **R3, verde:** salgadinhos para a prateleira **P1**, primeira gôndola à esquerda. E repõe; é uma tarefa extra.
- **VENDA #NNN, laranja:** caixa fechada daquele pedido. Deryk leva à marca **ENTREGA DE PEDIDOS** no balcão e usa E. Tab volta a Felps para registrar e concluir o pagamento.
- **CASCOS VAZIOS:** vão ao palete **DEVOLUÇÕES**. Não abastecem os móveis nem completam uma venda.

O marcador aponta para a caixa ou o destino atual. Caixas erradas mostram o destino correto e continuam nas mãos. Reposição antes da conversa com Felps funciona e fica registrada. Sábado/domingo não recriam caixas das tarefas concluídas da sexta. [Guia](docs/supplies_v021/README.md).

## Sexta-feira: apagão e fechamento

Depois do aviso e da saída do cliente, a energia cai. Use F para a lanterna. Com Felps, use E no posto do caixa para suspender o atendimento. Com Deryk, abra o estoque e recolha a chave no suporte junto à entrada, pelo lado interno. Abra a porta do pátio no fundo do estoque e ligue o gerador. Uma venda interrompida conserva dinheiro e troco parcial.

Conclua o último atendimento. Felps confere o caixa por E; Deryk examina a porta antiga nos fundos. Use o quadro da chave para apagar o salão. Na calçada, E no comando das portas à direita da entrada chama o companheiro, que vem andando. Com os dois fora, E novamente baixa as portas e conclui a sexta.

O resumo salva a sexta e permite começar sábado. Veja `docs/friday_v018/README.md`.

## Sábado: câmeras e pistas

Converse com Felps, atenda os dois pedidos e aguarde o cliente de boné sair. Com Felps no caixa, **C** abre as câmeras da fachada, estoque e pátio. O cenário é mostrado ao vivo; **Eventos do DVR** contém registros escritos, sem reprodução de vídeo arquivado. Anote o evento, separe o recibo e confira o canal do pátio.

Com Deryk e mãos livres, abra o estoque e examine a porta antiga e a caixa deslocada. Depois, volte a Felps e use **Caderno / decisões**. Escolha copiar os registros/recibo ou deixá-los no gravador; avisar o responsável ou esperar. Você pode rever essas duas escolhas antes de sair do monitor. Prepare a saída por E no comando das portas, à direita da entrada, ou escolha seguir sem preparar no caderno. Bryan e Zirico são opcionais.

Depois das três decisões, alguém força a porta do pátio. Feche o caixa com Felps, confira o estoque com Deryk, apague o salão no quadro e reúna a dupla na calçada para baixar as portas. A cópia efetiva dos registros e recibos, as pistas e as escolhas ficam salvas. Domingo continua a investigação e conclui a primeira versão jogável da campanha. Veja `docs/saturday_v019/README.md`.

## Domingo: gravação, revelação e fuga

Converse no balcão. Deryk abre a porta antiga no fundo do estoque, recolhe o módulo na sala de manutenção e leva-o fisicamente ao balcão. Com Felps, C abre a recuperação: reproduza o vídeo de quarta-feira e analise o trecho. O cadastro e as imagens revelam a ligação do cliente com o acesso antigo.

Antes de conferir o quadro do estoque, Felps pode copiar o fragmento para levar consigo e avisar o contato de confiança. Enviar a prova para fora preserva-a mesmo que o gravador seja destruído. Estas oportunidades continuam disponíveis se você não preparou ajuda no sábado.

Com Felps no terminal, Deryk confere o quadro. Durante a separação, Deryk abre o pátio e seleciona **ESTOQUE** no gerador. Alterne para Felps e use **C → DESTRAVAR ESTOQUE** no terminal energizado; também existe um comando junto à porta. **H** manda o companheiro acompanhar ou aguardar em cobertura. Os dois caminham pelo cenário. O assassino vê, ouve, investiga e procura no último ponto conhecido; trocar de personagem não apaga sua memória.

Apague a lanterna com F, agache e quebre a linha de visão. **Ctrl + E** junto às coberturas do balcão, armário do estoque ou freezer abaixa o corpo; mover-se ou usar E sai da cobertura. No comando manual à direita da entrada, E começa a abertura; fique perto até terminar. A preparação de sábado reduz a espera. O gerador também pode alimentar o SALÃO, reduzindo o tempo de abertura sem preparo.

Leve os dois ao mesmo encontro na calçada à direita. A ajuda avisada espera no primeiro ponto; a rota até o vizinho continua disponível mais adiante. E abre uma confirmação: fugir juntos com prova, fugir juntos sem prova ou confirmar sair sem o companheiro leva a três epílogos distintos. Cancelar permite voltar para resgatar. Ser alcançado abre **Retomar checkpoint da fuga**, sem registrar derrota como final permanente.

O save versão 5 conserva campanha, portas, circuito, prova, posições, coberturas e memória do perseguidor. Durante a fuga há salvamento a cada cinco segundos; o checkpoint de tentativa permanece separado. Formatos 1–4 continuam aceitos. Veja `docs/sunday_v020/README.md`.

## Atendimento

**Tab** alterna Deryk/Felps. Deryk cuida das caixas e reposição; Felps atende no balcão por **E**. **Espaço** avança as falas. Na frente de caixa, registre produtos/quantidades, receba o dinheiro, separe o troco e entregue a compra. **Esc** fecha a tela e **Tab** permite chamar Deryk. O pagamento usa dinheiro; cartão e Pix são próximas etapas.

Alguns pedidos exigem uma caixa fechada do estoque. Use **Chamar Deryk**, pegue a caixa do pedido, leve-a ao balcão e entregue com E. Volte a Felps para concluir a venda. Os produtos e valores aparecem no pedido e o total é calculado automaticamente.

O salvamento conserva pedido, cliente, registro, dinheiro recebido e troco parcial, além dos dois personagens e caixas. Checkpoints versões 1, 2 e 3 continuam aceitos. O monitor, a gaveta e os sons acompanham as etapas. Recibos e receita são registrados uma vez por compra concluída. Veja `docs/friday_v018`.

## Controles e configurações

- WASD e mouse: mover/olhar. Shift: correr. Ctrl: agachar.
- Tab: trocar entre Felps e Deryk. E: interagir e atender. C: câmeras/caderno/DVR, com Felps no caixa. H: acompanhar/aguardar no domingo.
- Q: apoiar caixa na marca verde; a marca vermelha indica bloqueio. Q durante a pegada agenda a soltura.
- Roda do mouse: aproximar até primeira pessoa ou afastar.
- Espaço: avançar diálogo. Esc: fechar monitor/caixa ou pausar. F: lanterna após o aviso narrativo.

Converse com Felps para iniciar. Reponha as duas caixas na geladeira e organize a caixa solta. A caixa fechada de um pedido tem identificação própria. Bryan e Zirico têm conversas opcionais.

O limite padrão é 30 FPS. Em Configurações, escolha 30 FPS, 60 FPS ou Sem limite. A estabilidade no PC alvo precisa de teste; veja `docs/optimization_v011`.

PS1 em 320×240 e PS1/2 em 640×480 ficam em **Configurações → Resolução interna / qualidade**. Ambos mantêm a janela grande e os menus em resolução normal. Mantenha a resolução global do projeto em 1280×720.

Os modelos e texturas foram preservados. A energia agora controla luzes e equipamentos. Créditos CC0 em `resources/material_sources/LICENSE.md`. O histórico do bug de largar caixas, corrigido na 0.16.0, e as próximas mecânicas ficam em `docs/PENDENCIAS.md`.

O elenco inclui Dery, Felps, Killer, Bryan, Zirico, Garota 1, Garota 2 e Velha 1. Os FBX originais ficam no [pacote fornecido pelo autor](https://drive.google.com/file/d/1qogHQIpLHR2YuTVj_vi3I2FP-i-Qapxe/view); as derivações necessárias para jogar já estão incluídas. Galerias históricas permanecem no [GitHub](https://github.com/Deriby/TheLastSale).

## Validação

Os resultados das seis suítes e a verificação da extração limpa ficam em `docs/natural_v022/validation.json` e na verificação de distribuição no GitHub. `./tools/test.sh` roda a suíte; em outra máquina, abra pelo editor ou defina `GODOT_BIN` com o caminho do motor.

A Godot 4.4 tem Windows 10 como requisito oficial mínimo. Windows 7/Radeon R7 não foram validados nativamente. O modo Econômica reduz resolução, sombras e acabamento dos materiais.

`PROJETO_MANIFESTO.json` registra o SHA-256 dos arquivos. Caches `.godot`, saves, Git e exportações para Windows não fazem parte deste pacote.
