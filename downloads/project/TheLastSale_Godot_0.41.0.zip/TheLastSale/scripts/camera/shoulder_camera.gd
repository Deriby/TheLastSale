class_name ShoulderCamera
extends Node3D
var arm: SpringArm3D
var camera: Camera3D
var target_distance:=2.5
var distance:=2.5
var pitch:=-.12
var yaw:=0.0
var first_person:=false
var shoulder:=.36
var allowed_shoulder:=.36
var occluded:=false
var probe: SphereShape3D
var focus_remaining:=0.0
var focus_target:=Vector3.ZERO
var focus_speed:=13.0
var focus_fov:=60.0
var focus_hide_body:=false
var focus_tracker: Callable
var kick_age:=-1.0
var kick_strength:=0.0
func focusing() -> bool:return focus_remaining>0.0
func focus_on(point: Vector3,seconds: float=1.5,speed: float=13.0,lens: float=60.0) -> void:
	focus_target=point;focus_remaining=seconds;focus_speed=speed;focus_fov=minf(Preferences.fov,lens)
	focus_hide_body=false
	focus_tracker=Callable();process_priority=0
func cancel_focus() -> void:
	focus_remaining=0.0;focus_hide_body=false;focus_tracker=Callable();process_priority=0;kick_age=-1;camera.rotation=Vector3.ZERO
func contact_kick(strength: float=1.0) -> void:
	kick_age=0.0;kick_strength=clampf(strength,0,1)
func _ready() -> void:
	top_level=true;physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
	position.y=1.58
	arm=SpringArm3D.new();probe=SphereShape3D.new();probe.radius=.18;arm.shape=probe;arm.margin=.10;arm.collision_mask=1
	add_child(arm)
	camera=Camera3D.new();camera.near=.055;camera.far=110;camera.current=true;arm.add_child(camera)
	arm.add_excluded_object(get_parent().get_rid())
	target_distance=Preferences.camera_distance;distance=target_distance;arm.spring_length=distance;camera.position.z=distance;arm.position.x=shoulder
	first_person=distance<.2
	if first_person:shoulder=0;arm.position.x=0
func handle_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and not focusing():
		yaw-=event.relative.x*Preferences.sensitivity
		pitch=clampf(pitch-event.relative.y*Preferences.sensitivity,-1.03,.86)
	if event is InputEventMouseButton and event.pressed:
		if event.button_index==MOUSE_BUTTON_WHEEL_UP:target_distance=maxf(0,target_distance-.24)
		if event.button_index==MOUSE_BUTTON_WHEEL_DOWN:target_distance=minf(3.6,target_distance+.24)
func _physics_process(_delta: float) -> void:
	# Test the lateral move too: SpringArm alone does not protect a shoulder offset.
	var desired:=.36*smoothstep(.1,1.0,distance)
	var motion:=global_basis.x*desired
	var query:=PhysicsShapeQueryParameters3D.new();query.shape=probe;query.transform=Transform3D(Basis.IDENTITY,global_position);query.motion=motion;query.collision_mask=1;query.exclude=[get_parent().get_rid()]
	var result:=get_world_3d().direct_space_state.cast_motion(query)
	allowed_shoulder=desired*(maxf(0,result[0]-.06) if result.size()>0 else 1.0)
func _process(delta: float) -> void:
	var player: DepotPlayer=get_parent()
	if focusing() and focus_tracker.is_valid():focus_target=focus_tracker.call()
	if focusing():
		var toward:=focus_target-global_position
		if toward.length()>.1:
			yaw=lerp_angle(yaw,atan2(-toward.x,-toward.z),1-exp(-delta*focus_speed))
			pitch=lerpf(pitch,clampf(asin(toward.normalized().y),-1.03,.86),1-exp(-delta*focus_speed))
		focus_remaining=maxf(0,focus_remaining-delta)
	rotation=Vector3(pitch,yaw,0)
	distance=lerpf(distance,target_distance,1-exp(-delta*13))
	first_person=distance<.25 and target_distance<.2
	var head:=player.motion.skeleton.get_bone_global_pose(player.motion.skeleton.find_bone("head"))
	var eyes: Vector3=player.motion.skeleton.global_transform*head.origin+Vector3.UP*.15
	var rest_eyes: float=player.motion.skeleton.get_bone_global_rest(player.motion.skeleton.find_bone("head")).origin.y*player.motion.skeleton.global_basis.get_scale().y+.15
	var third_height:=1.15 if player.crouching else 1.55
	var blend:=1-smoothstep(.15,1.0,distance)
	var eye_height:=eyes.y-player.global_position.y
	if not player.crouching:eye_height=lerpf(rest_eyes,eye_height,.20)
	var height:=lerpf(third_height,clampf(eye_height,1.0,1.72),blend)
	var center:=player.get_global_transform_interpolated().origin
	global_position=Vector3(center.x,lerpf(global_position.y,center.y+height,1-exp(-delta*16)),center.z)
	shoulder=minf(shoulder,allowed_shoulder) if allowed_shoulder<shoulder else lerpf(shoulder,allowed_shoulder,1-exp(-delta*7))
	arm.position.x=lerpf(arm.position.x,0.0 if focusing() else shoulder,1-exp(-delta*18))
	arm.position.z=-.16*blend
	arm.spring_length=maxf(0,distance)
	camera.fov=lerpf(camera.fov,focus_fov if focusing() else Preferences.fov,1-exp(-delta*(14 if focusing() else 8)))
	if kick_age>=0:
		kick_age+=delta
		var envelope:=kick_strength*exp(-kick_age*8.5)
		camera.rotation=Vector3(sin(kick_age*61)*.018,sin(kick_age*47)*.011,sin(kick_age*53)*.032)*envelope
		if kick_age>.70:kick_age=-1;camera.rotation=Vector3.ZERO
	var actual: float=camera.global_position.distance_to(global_position)
	if not first_person:
		if actual<.46:occluded=true
		elif actual>.68:occluded=false
	else:occluded=false
	player.visual.visible=true
	player.motion.set_first_person(first_person,occluded or focusing() and focus_hide_body and distance>.8)
	if not focusing() and focus_tracker.is_valid():focus_tracker=Callable();process_priority=0

func reset_follow() -> void:
	global_position=get_parent().global_position+Vector3.UP*1.55
	rotation=Vector3(pitch,yaw,0)
	reset_physics_interpolation()
